<?php
$servidor = "localhost";
$usuario = "id6973044_tec_inside01";
$senha = "meninosemeninas@";
$dbname = "id6973044_tec_db";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>
