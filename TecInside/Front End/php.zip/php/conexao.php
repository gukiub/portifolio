<?php
     $servidor = "localhost";
     $usuario = "root";
     $senha = "";
     $banco = "TecInside2";
     $conecta = mysqli_connect($servidor, $usuario, $senha, $banco);
?>