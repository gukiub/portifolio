Running OpenProj @version_name@

Requirements:
	OpenProj uses Sun Java Runtime Environment version 1.5 or later.  1.6 is preferred.
	To see what version you have, check out this page:
	http://www.java.com/en/download/help/testvm.xml

	You can download java here:  http://www.java.com/en/download/index.jsp

	If you are on Mac OS X 10.4 or later, java 1.5 is pre-installed.

Installation:
	Unzip the files to the folder of your choice.

	Windows: Click on openproj.jar (or openproj.bat)

	Mac: Click on openproj.jar

	Linux: Open a terminal, go to the openproj folder and run ./openproj.sh (assuming you downloaded the tar.gz archive)
			If you get a permission denied message, do "chmod +x openproj.sh"  This will let you run the shell script.
			You can also run with the command "sh openproj.sh"

			openproj.sh  will report an error if it doesn't find a valid Java installation on your system (Sun, IBM or IcedTea implementation, version >=1.5).
			On some distributions Sun/IBM/IcedTea JRE isn't installed by default, but it's often provided as an optional package.
