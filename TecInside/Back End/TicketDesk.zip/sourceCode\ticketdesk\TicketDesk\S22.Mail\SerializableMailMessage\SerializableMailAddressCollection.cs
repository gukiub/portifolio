﻿using System;
using System.Collections.ObjectModel;

namespace S22.Mail {
	[Serializable]
	public class SerializableMailAddressCollection : Collection<SerializableMailAddress> {
	}
}
